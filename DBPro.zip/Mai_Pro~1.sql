select sum(donorname)
from donors;
GRANT INSERT ANY TABLE TO Mai;
