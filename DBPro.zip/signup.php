<?php

// Oracle database connection parameters
$oracleUsername = 'MAI';
$oraclePassword = 'hr';
$oracleHostname = 'desktop-pulqdun';

// Create Oracle connection
$oracleConn = oci_connect($oracleUsername, $oraclePassword, $oracleHostname);

// Check if the connection is successful
if (!$oracleConn) {
    $error = oci_error();
    die("Failed to connect to Oracle: " . $error['message']);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve user input from the form
    $fullName = $_POST["fullName"];
    $signupPassword = $_POST["signupPassword"];

    // Validate and sanitize user input if needed

    // Hash the password before storing it in the database
    $hashedPassword = password_hash($signupPassword, PASSWORD_DEFAULT);

    // Insert the user information into the database
    // Replace 'your_table_name' with your actual table name
    $tableName = 'DONORS';

    // SQL query to insert user information into the 'donor' table
   // SQL query to insert user information into the 'donor' table
$sql = "INSERT INTO $tableName (DONORNAME, PASSWORD) VALUES (:fullName, :hashedPassword)";

// Add this line for debugging
echo "SQL Query: $sql\n";

$stmt = oci_parse($oracleConn, $sql);

if (!$stmt) {
    $error = oci_error($oracleConn);
    die("Failed to prepare the SQL statement: " . $error['message']);
}

// Bind variables
oci_bind_by_name($stmt, ":fullName", $fullName);
oci_bind_by_name($stmt, ":hashedPassword", $hashedPassword);

// Execute the statement
$result = oci_execute($stmt);

// Add this block for debugging
if (!$result) {
    $error = oci_error($stmt);
    die("Error: " . $error['message']);
}

oci_free_statement($stmt);
echo "Signup successful!";
} else {
    // Redirect to the signup page if accessed directly without submitting the form
    header("Location: signup_page.php");
    exit();
}
$err = oci_error($stmt);
if ($err) {
    var_dump($err);
    die("Error executing statement");
}

// Close the Oracle connection
?>
